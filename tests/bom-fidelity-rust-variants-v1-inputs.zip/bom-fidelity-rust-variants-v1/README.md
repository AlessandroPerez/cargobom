# BOM Fidelity Rust controlled inputs

Five input variants of cbom-real-crates-app for the next generator runs.
Their source hashes match the expectations frozen on 14 October 2026.
Expected labels and reference CBOMs are not included in this input package.

Each directory is a standalone Cargo workspace with its own copy of the
original Cargo.toml, pinned Cargo.lock and upstream MIT notice:

- remove-md5-operation
- replace-app-sha256-with-sha512
- change-pbkdf2-rounds
- move-call-sites
- initialization-only-application

Please use the same generator, toolchain, target, release profile and default
features as for the original case. Do not update Cargo.lock. The declared
toolchain is nightly-2026-09-25, rustc 1.100.0-nightly (f7575a9da 2026-09-24),
target x86_64-unknown-linux-gnu. Preserve the same driver flags, including
-Zalways-encode-mir, -Zmir-opt-level=0 and -Zspan-free-formats.

For each directory, return one CycloneDX 1.7 CBOM named after its directory.
Please include the generator version or commit, exact command/flags and any
warnings or failures. A failed run is useful evidence; keep its diagnostics.
These inputs require cargo check/analysis, not execution of the application.

After extraction, `python verify.py` verifies the package hashes. The original
fixture is pinned to cdxgen/cdxgen-plugins-bin commit
6a646353e4fbd9d64fa115176241d7a233e19630,
thirdparty/rusi/fixtures/cbom-real-crates-app. Original and modified fixture
copies retain the upstream licence notice.
