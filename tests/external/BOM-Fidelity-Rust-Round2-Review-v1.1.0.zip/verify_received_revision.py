"""Portable integrity and source-binding checks; no generator or product imports."""
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
from zipfile import ZipFile

def sha(raw):return hashlib.sha256(raw).hexdigest()

def safe(name):
    path=PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and '\\' not in name and ':' not in name
    assert name and path.as_posix()==name

def members(path):
    assert path.stat().st_size<16*1024**2
    result={}
    with ZipFile(path) as stream:
        entries=stream.infolist()
        assert len(entries)<=128 and sum(x.file_size for x in entries)<128*1024**2
        for entry in entries:
            safe(entry.filename)
            assert not entry.is_dir() and not entry.flag_bits&1 and entry.filename not in result
            assert stat.S_IFMT(entry.external_attr>>16) in (0,stat.S_IFREG) and entry.file_size<32*1024**2
            result[entry.filename]=stream.read(entry)
    return result

def verify(root,manifest_sha,old_zip,new_zip,reference_zip):
    raw=(root/'MANIFEST.json').read_bytes()
    assert sha(raw)==manifest_sha
    manifest=json.loads(raw)
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.relative_to(root).as_posix()!='MANIFEST.json'}
    assert actual==set(manifest['files'])
    for name,row in manifest['files'].items():
        safe(name)
        path=root/name
        assert not path.is_symlink() and path.is_file()
        data=path.read_bytes()
        assert len(data)==row['bytes'] and sha(data)==row['sha256']
    identities=json.loads((root/'input-identities.json').read_bytes())
    assert sha(old_zip.read_bytes())==identities['v1ZipSha256']
    assert sha(new_zip.read_bytes())==identities['v2ZipSha256']
    assert sha(reference_zip.read_bytes())=='d3acc8bcf5ef060ed67c65c30aea98d64fd8258447616b4b3b313bbc8599c47c'
    old=members(old_zip);new=members(new_zip);frozen=members(reference_zip)
    assert sha(frozen['MANIFEST.json'])==identities['frozenManifestSha256']
    assert sha(frozen['reference-labels.v1.json'])==identities['frozenLabelsSha256']
    declared=json.loads(frozen['MANIFEST.json'])['files']
    assert set(frozen)==set(declared)|{'MANIFEST.json'}
    for name,row in declared.items():assert sha(frozen[name])==row['sha256'] and len(frozen[name])==row['bytes']
    for name,row in identities['files'].items():
        assert sha(old[name])==row['v1Sha256'] and sha(new[name])==row['v2Sha256']
        assert (old[name]==new[name])==row['unchangedBytes']
    source_identity=json.loads(frozen['source-identities.json'])['packages']
    sources={}
    for package,row in source_identity.items():
        with tarfile.open(fileobj=io.BytesIO(frozen[row['archive']]),mode='r:gz') as stream:
            entries=stream.getmembers()
            assert len(entries)<16384 and sum(x.size for x in entries)<128*1024**2
            sources[package]={}
            prefix=package.replace('@','-')+'/'
            for entry in entries:
                safe(entry.name)
                assert entry.isfile() or entry.isdir()
                if entry.isfile():
                    assert entry.name.startswith(prefix) and entry.size<16*1024**2
                    sources[package][entry.name[len(prefix):]]=stream.extractfile(entry).read()
    documents={case:json.loads(new[name]) for case,name in [('jwt-cli','jwt-cli-6.1.1.cbom.json'),('hkdf','hkdf-0.12.4.cbom.json')]}
    count=0
    for row in json.loads((root/'occurrence-anchors.json').read_bytes()):
        component=next(x for x in documents[row['case']]['components'] if x['bom-ref']==row['componentRef'])
        occurrence=component['evidence']['occurrences'][row['occurrenceIndex']]
        assert occurrence['line']==row['line'] and occurrence.get('offset',0)==row['offset']
        data=frozen['locks/'+row['case']+'.Cargo.lock'] if row['file']=='Cargo.lock' else sources[row['package']][row['file']]
        assert sha(data)==row['sourceSha256']
        line=data.decode().splitlines()[row['line']-1]
        assert line==row['sourceLine']
        if row['cryptoRecord']:
            assert row['code'] and line[row['offset']:].startswith(row['code'])
            match=re.search(r'code: `([^`]+)`',occurrence['additionalContext'])
            assert match and match.group(1)==row['code']
            count+=1
    assert count==147
    findings=json.loads((root/'focused-findings.json').read_bytes())
    assert len(findings['checks'])==28 and all(findings['checks'].values())
    jwt={x['name']:x for x in documents['jwt-cli']['components']}
    for bits in (256,384,512):
        properties={x['name']:x['value'] for x in jwt[f'RSA-PSS-SHA-{bits}']['properties']}
        assert properties['rcbom:param:salt_bytes']==str(bits//8) and properties['rcbom:param:mgf']==f'MGF1-SHA-{bits}'
    assert next(x for x in documents['jwt-cli']['dependencies'] if x['ref']=='crypto:algorithm:Ed25519')['dependsOn']==['crypto:algorithm:SHA-512']
    return {'status':'PASS_ARTIFACTS_AND_SOURCE_BINDINGS','cryptoTokenBindings':count,
            'frozenReferenceModified':False,'generatorExecuted':False,'semanticAdjudicationAutomated':False}

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('root',type=Path)
    parser.add_argument('--manifest-sha256',required=True)
    parser.add_argument('--v1-zip',type=Path,required=True)
    parser.add_argument('--v2-zip',type=Path,required=True)
    parser.add_argument('--reference-zip',type=Path,required=True)
    args=parser.parse_args()
    print(json.dumps(verify(args.root,args.manifest_sha256,args.v1_zip,args.v2_zip,args.reference_zip),sort_keys=True))
