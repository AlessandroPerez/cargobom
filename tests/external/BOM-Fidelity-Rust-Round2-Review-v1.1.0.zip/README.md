# Updated second round CBOM review

Read REPORT.md for the findings and limits. The reference labels are unchanged;
the HMAC records remain qualified conservative candidates, not confirmed
verification in the two signature-disabled source contexts.

The data files preserve case summaries, announced changes, source excerpts and
source-token bindings. The two review runs produced identical bytes and passed
28 positive checks and nine documentary mutation controls each.

For an independent read-only binding check, use Python 3.11 or newer:

```sh
python3 -B verify_received_revision.py . \
  --manifest-sha256 EXPECTED_MANIFEST_SHA256 \
  --v1-zip /inputs/round2-cboms.zip \
  --v2-zip /inputs/round2-cboms-v2.zip \
  --reference-zip /inputs/BOM-Fidelity-Rust-Reference-Round2-v1.0.0.zip
```

The expected manifest SHA-256 is provided in the separate delivery receipt.
All three inputs are the previously exchanged ZIPs, not extracted replacements.
The checker validates integrity, input identities and source bindings; it does
not run the generator, compile Rust or automate semantic adjudication. No
third-party Python dependencies are required.

This package excludes received CBOM files, private comparison code, product
source, infrastructure and credentials. It is for the owner and author exchange;
publication is a separate action. No message or public repository is updated
automatically by preparing it.
