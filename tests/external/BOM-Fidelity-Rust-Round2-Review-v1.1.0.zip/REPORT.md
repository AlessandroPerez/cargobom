# Review of the updated second round Rust CBOMs

José Ángel Olivares · BOM Fidelity / Global Trade Origin · 23 October 2026

The updated jwt-cli 6.1.1 CBOM addresses the three reported representation
points: it qualifies the conservative HMAC candidates at signature-disabled
decode calls, adds the fixed RSA-PSS parameters, and relates Ed25519 to SHA-512
with constituent occurrences. The hkdf 0.12.4 CBOM is byte-identical to v1.
The original frozen source reference remains unchanged.

## Corrections and remaining interpretation

| Point | Result |
| --- | --- |
| RSA-PSS | Salt lengths 32, 48 and 64 bytes and MGF1-SHA-256, MGF1-SHA-384 and MGF1-SHA-512 match the respective fixed source expectations. |
| Ed25519 | The dependency on SHA-512 is explicit. Four new SHA-512 constituent records cover the application sign/verify calls and the corresponding jsonwebtoken calls into ring. The five pre-existing SHA-512 records are retained. |
| Signature-disabled decoding | All six HMAC candidates at jwt-cli decode.rs lines 152 and 169 remain, with the added condition that signature validation is disabled on a way to the call and that there it only decodes. |
| JWK provenance | The setup at utils.rs line 170 includes computed provenance through parse_jwks, retaining the parameter alternative. The aggregate property is computed,parameter. |
| Empty HMAC secret | The shared jsonwebtoken verifier's key-setup context now retains the possible empty, computed and parameter origins. It still describes setup, not a cryptographic operation. |
| HKDF | The received document is unchanged, including its generic HMAC family with the hash left open. |

The HMAC annotation is an improvement in communicating a conservative analysis,
not proof of path-sensitive verification. In the pinned application source,
`insecure_validator` is created at line 145 and signature checking is disabled
at line 148 before the calls at 152 and 169. In jsonwebtoken, the actual
verification call is guarded by `validation.validate_signature`. These specific
source contexts therefore remain decoding-only in our reference. We retain the
generator records as qualified candidates, not six confirmed HMAC verifications.
The author's explanation is that its facts cannot prove the disabling call
runs on every way to a call; it preserves candidates to avoid losing a possible
verification elsewhere. No runtime execution is inferred from those records.

Computed JWK provenance here means a value obtained by parsing the supplied
JWKS and selecting its key, not cryptographic key generation. Likewise, a
possible empty key flowing into a shared verification function does not prove
that verification executes with that key on the signature-disabled paths.
The joined provenance must retain the same control-flow qualification.

The earlier question about the exact treatment of public hmac/digest re-export
roots is not answered by this update. It remains an explicit scope boundary,
not a count of missing algorithms or a reason to reopen the corrected parameters.

## Preservation and change review

Both documents validate against the previously pinned CycloneDX 1.7 schema and
registry. No document references dangle, and all **147 crypto occurrence records**
match their pinned source tokens: 138 in jwt-cli and nine in hkdf. Twelve
manifest occurrences are kept separate. The four-record increase over v1 is
the Ed25519/SHA-512 constituent representation, not four newly discovered
independent application operations. Component counts remain 27 and six;
algorithm-component counts remain 15 and one.

All twelve JWT choices remain represented at signing and normal verification.
The hkdf document still has four operation and five setup records and does not
invent a concrete caller-selected hash.

There are 18 changed field or collection records in jwt-cli after ignoring only
the document serial number and ordering of component, dependency, property and
edge-target lists, preserving multiplicity. They comprise six HMAC context
annotations, six PSS properties, the SHA-512 occurrence list and count, three
key-provenance fields and the Ed25519 dependency edge. There are no changes
outside these announced paths. HKDF is unchanged at the raw-byte level.

## Verification and inputs

Two isolated, network-disabled Linux runs produced byte-identical output for
the comparison, focused findings, source excerpts, differences, input identities,
summary and controls. Each passed 28 positive checks and nine documentary
mutation controls covering wrong salt/MGF values, missing relations, altered
constituent positions, unrelated edits, unqualified or dropped HMAC candidates
and missing provenance annotations. These are checks of this review and these
documents, not a global accuracy score for the generator.

The received ZIP is `round2-cboms-v2.zip`, 9,048 bytes, SHA-256
`0464092138a292bcecfbeab2ee9bcbb3fd9797c3d77866c6afdb25f20d35f0f8`.
The fixed reference label SHA-256 remains
`b088bb7a78b6f689758b63d08724f24118c4ff07d395b0d6b905a2ceb07b79f4`.
The supplier states the same inputs and configuration were used. This review
reads the received documents and pinned sources; it does not run the generator
or execute the Rust applications. No production service or frozen label was changed.

The two requested parameter/relationship corrections are verified. The HMAC
point is now documented as a qualified conservative-analysis limitation, rather
than presented as confirmed verification. The public re-export boundary remains
unconfirmed. No additional variant run is needed to verify these supplied changes.

Website: [BOM Fidelity](https://bomfidelity.globaltradeorigin.com/).
