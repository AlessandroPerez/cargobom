# Rust round-two v3 boundary-list review — addendum 1.3.0

Read REPORT.md first. The 1.0.0 reference and the previous 1.2.0 CBOM review
remain unchanged. This package contains this new review, row-level evidence,
source identities, controls and a standalone integrity/source-anchor checker.
It contains neither the product engine nor the supplier's raw CBOM/TSV ZIPs.

Verification requires Python 3.11 or later, with no third-party dependencies.
The manifest's expected SHA-256 is provided in the accompanying message.

```
python3 verify_delivery.py --manifest-sha256 MANIFEST_SHA256_FROM_MESSAGE
```

To also bind the producer's exact TSVs and all source anchors, provide the
original call-list ZIP, unpacked frozen reference 1.0.0, and a folder containing
the three .crate archives listed in supplementary-source-identities.json:

```
python3 verify_delivery.py --manifest-sha256 MANIFEST_SHA256_FROM_MESSAGE \
  --calls-zip /path/to/round2-call-lists-v3.zip \
  --reference /path/to/reference-1.0.0 \
  --supplementary /path/to/three-crate-archives
```

The original reference is at:
https://github.com/jaooli-cyber/rust-cbom-reference-cases/releases/tag/v1.0.0

The checker reads archives without extracting arbitrary paths and never fetches
URLs or executes Rust. It verifies hashes, exact TSV fields and source anchors;
it does not repeat the reason adjudication, schema checks or MIR call graph.
Supplementary archives must match the unchanged Cargo.lock checksums.

Source excerpts retain their upstream licenses, reproduced in SOURCE-LICENSES.
The exact package versions and source hashes are recorded in the evidence.

José Ángel Olivares · BOM Fidelity / Global Trade Origin
https://bomfidelity.globaltradeorigin.com/
