# Rust CBOM reference cases — v3 call-list review

Review addendum **1.3.0** · 26 October 2026  
José Ángel Olivares · BOM Fidelity / Global Trade Origin  
https://bomfidelity.globaltradeorigin.com/

## Result

Both supplied lists agree with the boundary summaries in the previously
reviewed v3 CBOMs. All **260 exported rows** have valid file/line/Unicode-offset
anchors in checksum-bound source archives. The **42 cited rows** match crypto
occurrences at the same positions. The remaining **218 rows** have source-level
support for their stated dispositions within the described boundary.

This is an extension of the documentary review, with the original reference
and labels unchanged. It does not independently rebuild the generator's MIR
call graph or prove that the list contains every possible call. No generator,
Rust build, product engine or production service was executed for this review.

| Case | Exported rows | Cited | Excused | Distinct positions | Matched crypto occurrence records |
| --- | ---: | ---: | ---: | ---: | ---: |
| jwt-cli 6.1.1 | 247 | 33 | 214 | 93 | 95 |
| hkdf 0.12.4 | 13 | 9 | 4 | 13 | 9 |

Rows, source positions, crypto components and occurrence records are different
units. Multiple records may describe one call, including conservative algorithm
candidates or key setup. The six HMAC candidates at the two signature-disabled
application sites remain qualified candidates; their citation is not evidence
of signature verification on those paths.

## Fixed evidence

Generator revision declared by the producer:
`9a8249cd8afacf8698f6f4cb855cc758a2ec2f78`, the v3 build. Inputs, locks and flags
are declared unchanged: nightly-2026-09-25, release/default features,
x86_64-unknown-linux-gnu, `-Zalways-encode-mir -Zmir-opt-level=0
-Zspan-free-formats`, with the walk check. Export command:

```
cargo cbom --check-walk -o <case>.cbom.json --boundary-list <case>.calls.tsv
```

The command is recorded as producer provenance; it was not executed here.
The supplied archive contains only the two TSVs. The producer's statement that
the CBOMs written alongside were byte-identical to v3 is recorded as a statement,
not a comparison of sidecar bytes that were not supplied. Our checks use the
unchanged v3 archive already reviewed in addendum 1.2.0.

| Artifact | SHA-256 |
| --- | --- |
| Call-list ZIP | `781a6adb0b885815cfe7338ece6b534310c4f653778cb90541474f93115e4946` |
| jwt-cli TSV | `0e9ef5dbfe432715203dc426d4dee5199c8ed507248e250cbced6d8d01beef9a` |
| hkdf TSV | `5b81594191d8cf98f52e5768b72f3d70b336ffcdd72f55289a04604ea8b37dc0` |
| Previously reviewed v3 CBOM ZIP | `8e5a163f93c64d8a49cacbbf40d0c5f89dcba6e3d762f9eae4215429e0db933c` |
| Frozen reference manifest 1.0.0 | `44cc35d53303c0c50a583339bc1597ec2d3e3e256528e7c926770a6cb2531a0d` |
| Frozen labels | `b088bb7a78b6f689758b63d08724f24118c4ff07d395b0d6b905a2ceb07b79f4` |

The public source reference remains
[release v1.0.0](https://github.com/jaooli-cyber/rust-cbom-reference-cases/releases/tag/v1.0.0).
Its contents, labels and earlier CBOM reviews were not rewritten.

## Source review and dispositions

The TSV parser preserves all six columns, commas in function paths, traits,
caller context and multiplicity. The offset counts Unicode characters, starting
at zero; lines start at one. Distinct generic resolutions at the same source
position are retained. The owner column is retained as an exported execution
context; it is not inferred merely from the source file or caller namespace.

Source review covers every row. Reported method names appear at the specified
source suffix, with explicit treatment of eleven formatting delegations and
three Serde `deref_impl!` macro expansion sites. Source compatibility is not a
recompilation of fully qualified MIR resolution, traits or context propagation.
The row-level assessment file keeps that distinction explicit.

For hkdf:

- Nine calls into hmac/digest match the nine cited occurrence records. They
  include setup and operations; no caller-selected hash is invented.
- `src/lib.rs:181:8` and `:282:8` call `AlgorithmName::write_alg_name` inside
  the two Debug implementations. They format an algorithm name rather than
  perform an additional cryptographic operation.
- `src/sealed.rs:52:36` and `:83:13` clone existing HMAC state. They do not
  establish fresh key generation or an additional algorithm use.

For jwt-cli:

- All 33 cited rows match 95 crypto occurrence records at their exact positions.
- The 195 `entered` rows target jsonwebtoken code, spanning 42 source positions.
  They include derived serialization/deserialization callbacks and application
  delegation. They are not 195 additional cryptographic operations.
- The other dispositions are format 11, view 2, generator setup 2, accessor 1,
  comparison 1, copy 1 and public half 1. Source expressions support those roles.
- The constant-time comparison participates in the reported HMAC verification
  path. Its classification is a supporting comparison within that reporting
  boundary, not a claim that constant-time code has no cryptographic role.

The 43 jwt-cli crypto occurrences not matched to a boundary-list row reconcile
as 20 static observations, 19 constituent/component observations and four
same-package key-setup calls. The latter are the RSA/EC/Ed key constructors
inside `DecodingKey::from_jwk` and `EncodingKey::from_secret` inside HMAC
verification. These units are kept separate from cross-package boundary calls;
their different counts are not presented as missing algorithms.

## Supplementary source identities

The frozen reference supplies the sources for 69 rows. For the remaining 191,
three source archives were acquired separately and checked against the exact
checksums in the unchanged jwt-cli Cargo.lock:

| Source | SHA-256 |
| --- | --- |
| base64 0.21.7 | `9d297deb1925b89f2ccc13d7635fa0714f12c87adce1c75356b39ca9b7178567` |
| serde 1.0.147 | `d193d69bae983fc11a79df82342761dfbf28a99fc8d203dca4c3c1b590948965` |
| serde_json 1.0.99 | `46266871c240a00b8f503b877622fe33430b3c7d963bdc0f2adc511e54a1eae3` |

The frozen lock SHA-256 is
`2f6ef322f5a38d400df782718a5c703a54ad85ac09c3a1e5757c9b664ca8a0e0`.
The supplementary acquisition file records their public URLs and identities.
They were read as source data, without building or executing them. They were
not inserted into the frozen package or labels. Source-license texts accompany
the excerpts included in the row-level review.

## Verification and limits

Two accepted independent passes produce identical review files. Each detects
22 negative mutations and passes two positive controls, covering TSV structure,
duplicate/contradictory calls, partitions, source/citation shifts, balanced
reason swaps, generic commas and Unicode-character offsets.

The supplied portable checker verifies the delivery and can independently bind
the received TSV rows and all 260 source anchors using the public reference
and the three checksum-bound supplementary archives. It needs only Python 3.11
or later. It does not execute Rust or repeat the generator, previous schema
validation, MIR resolution or the source-level reason adjudication.

The original reference, CBOM v3 review and agreed interpretations remain intact.
We found no additional change required to the CBOMs from this boundary-list
review. The detailed list supports the reported accounting; it is not, by
itself, an independent proof that no unlisted call exists or that every static
candidate is feasible at runtime.
