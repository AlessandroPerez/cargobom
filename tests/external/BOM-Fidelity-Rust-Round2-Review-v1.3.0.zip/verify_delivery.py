"""Standalone delivery/input/source-anchor integrity checks; Python 3.11+."""
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import tarfile
import tomllib
from zipfile import ZipFile


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def safe_path(root, name):
    part = PurePosixPath(name)
    assert name and part.as_posix()==name and not part.is_absolute() and '..' not in part.parts
    assert '\\' not in name and ':' not in name
    path = root / name
    assert path.resolve().is_relative_to(root.resolve()) and not path.is_symlink()
    return path


def crate_sources(path, package):
    result={}
    name,version=package.split('@')
    assert path.stat().st_size <= 16*1024**2
    with tarfile.open(path,'r:gz') as archive:
        members=archive.getmembers()
        assert len(members)<16384 and sum(m.size for m in members)<=128*1024**2
        for member in members:
            part=PurePosixPath(member.name)
            assert not part.is_absolute() and '..' not in part.parts and '\\' not in member.name
            assert part.parts[0]==name+'-'+version and (member.isfile() or member.isdir())
            if member.isfile():
                relative='/'.join(part.parts[1:])
                assert relative and relative not in result
                result[relative]=archive.extractfile(member).read()
    return result


def verify(folder, expected, calls_zip=None, reference=None, supplementary=None):
    raw=(folder/'MANIFEST.json').read_bytes()
    assert sha(raw)==expected, 'manifest identity'
    manifest=json.loads(raw)
    assert manifest['reviewVersion']=='1.3.0'
    actual=set()
    for path in folder.rglob('*'):
        assert not path.is_symlink()
        if path.is_file() and path!=folder/'MANIFEST.json':
            actual.add(path.relative_to(folder).as_posix())
    assert actual==set(manifest['files']), 'delivery file set'
    for name,record in manifest['files'].items():
        data=safe_path(folder,name).read_bytes()
        assert len(data)==record['bytes'] and sha(data)==record['sha256'], name
    review=json.loads((folder/'review.json').read_bytes())
    assessed=json.loads((folder/'all-call-assessments.json').read_bytes())
    assert sum(len(rows) for rows in assessed.values())==260
    inputs_bound=False
    if calls_zip:
        assert calls_zip.stat().st_size<=2*1024**2 and sha(calls_zip.read_bytes())==review['zipSha256']
        with ZipFile(calls_zip) as stream:
            assert set(stream.namelist())=={'jwt-cli-6.1.1.calls.tsv','hkdf-0.12.4.calls.tsv'}
            assert len(stream.infolist())==2 and sum(m.file_size for m in stream.infolist())<=4*1024**2
            for case,name in [('jwt-cli','jwt-cli-6.1.1.calls.tsv'),('hkdf','hkdf-0.12.4.calls.tsv')]:
                item=stream.getinfo(name)
                assert not item.flag_bits&1 and stat.S_IFMT(item.external_attr>>16) in (0,stat.S_IFREG)
                data=stream.read(item)
                assert sha(data)==review['cases'][case]['inputTsvSha256']
                rows=list(csv.reader(io.StringIO(data.decode('utf-8'),newline=''),delimiter='\t',quoting=csv.QUOTE_NONE,strict=True))
                assert len(rows)==len(assessed[case])
                for fields,record in zip(rows,assessed[case]):
                    assert fields==[record[k] for k in ('position','verdict','callee','trait','caller','owner')]
        inputs_bound=True
    checked=0
    if reference is not None or supplementary is not None:
        assert reference is not None and supplementary is not None
        raw=(reference/'MANIFEST.json').read_bytes()
        assert sha(raw)==review['frozenReferenceManifestSha256']
        frozen=json.loads(raw)
        raw=(reference/'source-identities.json').read_bytes()
        assert sha(raw)==frozen['files']['source-identities.json']['sha256']
        identities=json.loads(raw)['packages']
        extra=json.loads((folder/'supplementary-source-identities.json').read_bytes())
        raw=(reference/'locks/jwt-cli.Cargo.lock').read_bytes()
        assert sha(raw)==frozen['files']['locks/jwt-cli.Cargo.lock']['sha256']==extra['frozenLockSha256']
        locked=tomllib.loads(raw.decode())['package']
        supplement={row['package']:row for row in extra['packages']}
        used={r['source']['package'] for rows in assessed.values() for r in rows}
        sources={}
        for package in sorted(used):
            if package in identities:
                name=identities[package]['archive']
                path=safe_path(reference,name)
                assert sha(path.read_bytes())==frozen['files'][name]['sha256']
            else:
                row=supplement[package]
                name,version=package.split('@')
                matches=[p for p in locked if p['name']==name and p['version']==version]
                assert len(matches)==1 and matches[0]['checksum']==row['sha256']
                path=safe_path(supplementary,row['archive'])
                assert sha(path.read_bytes())==row['sha256']
            sources[package]=crate_sources(path,package)
        for rows in assessed.values():
            for row in rows:
                anchor=row['source']
                raw=sources[anchor['package']][anchor['relative']]
                assert sha(raw)==anchor['sourceSha256']
                line=raw.decode('utf-8').splitlines()[row['line']-1]
                assert line==anchor['sourceLine'] and line[row['offset']:]==anchor['tokenTail']
                checked+=1
    return dict(status='PASS_BOUNDARY_REVIEW_INTEGRITY',files=len(actual),
                inputCallListsBound=inputs_bound,sourceAnchorsChecked=checked,
                generatorExecuted=False,mirResolutionChecked=False,reasonAdjudicationRerun=False,
                productEngineRequired=False)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest-sha256',required=True)
    parser.add_argument('--calls-zip',type=Path)
    parser.add_argument('--reference',type=Path)
    parser.add_argument('--supplementary',type=Path)
    args=parser.parse_args()
    print(json.dumps(verify(Path(__file__).resolve().parent,args.manifest_sha256,
                           args.calls_zip,args.reference,args.supplementary),sort_keys=True))
