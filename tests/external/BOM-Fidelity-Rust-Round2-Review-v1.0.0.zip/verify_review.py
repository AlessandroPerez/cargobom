"""Portable data-only checks of review artifacts and their two declared input ZIPs."""

import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
from zipfile import ZipFile


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def safe(name):
    p = PurePosixPath(name)
    assert name and not p.is_absolute() and '..' not in p.parts and '\\' not in name and ':' not in name
    assert p.as_posix() == name
    return p


def members(path, maximum):
    assert path.stat().st_size <= maximum
    result = {}
    with ZipFile(path) as zipped:
        entries = zipped.infolist()
        assert len(entries) <= 128 and sum(x.file_size for x in entries) <= 128 * 1024**2
        for entry in entries:
            safe(entry.filename)
            assert not entry.is_dir() and not entry.flag_bits & 1
            assert stat.S_IFMT(entry.external_attr >> 16) in (0, stat.S_IFREG)
            assert entry.filename not in result and entry.file_size <= 32 * 1024**2
            result[entry.filename] = zipped.read(entry)
    return result


def source_files(raw, prefix):
    result = {}
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archived:
        rows = archived.getmembers()
        assert len(rows) < 16384 and sum(x.size for x in rows) <= 128 * 1024**2
        for row in rows:
            safe(row.name)
            assert row.isfile() or row.isdir()
            if row.isfile():
                assert row.name.startswith(prefix + '/') and row.size <= 16 * 1024**2
                name = row.name[len(prefix)+1:]
                assert name not in result
                with archived.extractfile(row) as content:
                    result[name] = content.read()
    return result


def verify(root, manifest_sha, received, reference):
    manifest_raw = (root / 'MANIFEST.json').read_bytes()
    assert sha(manifest_raw) == manifest_sha
    manifest = json.loads(manifest_raw)
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name != 'MANIFEST.json'}
    assert actual == set(manifest['files'])
    for name, expected in manifest['files'].items():
        safe(name)
        p = root / name
        assert not p.is_symlink() and p.is_file() and p.stat().st_size == expected['bytes']
        assert sha(p.read_bytes()) == expected['sha256']
    identity = json.loads((root / 'provenance.json').read_bytes())
    assert sha(received.read_bytes()) == identity['receivedZipSha256']
    assert sha(reference.read_bytes()) == identity['frozenZipSha256']
    received_files = members(received, 16 * 1024**2)
    for name, expected in identity['receivedFiles'].items():
        assert sha(received_files[name]) == expected
    original = {case: json.loads(received_files[filename]) for case, filename in identity['caseFiles'].items()}
    frozen = members(reference, 16 * 1024**2)
    assert sha(frozen['MANIFEST.json']) == identity['frozenManifestSha256']
    assert sha(frozen['reference-labels.v1.json']) == identity['frozenLabelsSha256']
    frozen_manifest = json.loads(frozen['MANIFEST.json'])
    assert set(frozen) == set(frozen_manifest['files']) | {'MANIFEST.json'}
    for name, expected in frozen_manifest['files'].items():
        assert sha(frozen[name]) == expected['sha256'] and len(frozen[name]) == expected['bytes']
    source_identity = json.loads(frozen['source-identities.json'])
    sources = {package: source_files(frozen[value['archive']], package.replace('@', '-'))
               for package, value in source_identity['packages'].items()}
    anchors = json.loads((root / 'occurrence-anchors.json').read_bytes())
    count = 0
    for row in anchors:
        component = next(x for x in original[row['case']]['components'] if x['bom-ref'] == row['componentRef'])
        occurrence = component['evidence']['occurrences'][row['occurrenceIndex']]
        assert occurrence['line'] == row['line'] and occurrence.get('offset', 0) == row['offset']
        if row['file'] == 'Cargo.lock':
            raw = frozen['locks/' + row['case'] + '.Cargo.lock']
        else:
            raw = sources[row['package']][row['file']]
        assert sha(raw) == row['sourceSha256']
        line = raw.decode().splitlines()[row['line']-1]
        assert line == row['sourceLine']
        if row['cryptoRecord']:
            assert row['code'] and line[row['offset']:].startswith(row['code'])
            match = re.search(r'code: `([^`]+)`', occurrence['additionalContext'])
            assert match and match.group(1) == row['code']
            count += 1
    assert count == 143
    observed = json.loads((root / 'focused-observations.json').read_bytes())
    assert len(observed['signatureDisabledVerifyAnnotations']) == 6
    for row in observed['signatureDisabledVerifyAnnotations']:
        component = next(x for x in original['jwt-cli']['components'] if x['bom-ref'] == row['componentRef'])
        occurrence = component['evidence']['occurrences'][row['occurrenceIndex']]
        assert occurrence['location'] == 'src/translators/decode.rs' and occurrence['line'] in (152, 169)
        assert 'use: verify' in occurrence['additionalContext'] and 'possible' in occurrence['additionalContext']
    jwt_algorithms = {x['bom-ref']: x for x in original['jwt-cli']['components'] if x.get('cryptoProperties', {}).get('assetType') == 'algorithm'}
    for row in observed['pssParameterRepresentations']:
        text = json.dumps(jwt_algorithms[row['componentRef']]).lower()
        assert ('salt' in text) == row['explicitSaltRepresented'] == False
        assert ('mgf1' in text) == row['explicitMgfRepresented'] == False
    edges = {x['ref']: x for x in original['jwt-cli']['dependencies']}
    ed = observed['ed25519Sha512Relation']
    assert ed['ed25519'] in jwt_algorithms and ed['sha512'] in jwt_algorithms
    assert ed['sha512'] not in edges[ed['ed25519']].get('dependsOn', [])
    assert ed['ed25519'] not in edges[ed['sha512']].get('dependsOn', [])
    dispositions = json.loads((root / 'site-alignment.json').read_bytes())
    labels = json.loads(frozen['reference-labels.v1.json'])
    assert {x['id'] for x in dispositions} == {x['id'] for x in labels['sites']}
    for excerpt in json.loads((root / 'source-evidence.json').read_bytes()):
        raw = sources[excerpt['package']][excerpt['file']]
        assert sha(raw) == excerpt['sourceSha256']
        lines = raw.decode().splitlines()
        assert all(lines[x['line']-1] == x['text'] for x in excerpt['lines'])
    return {'status': 'PASS_REVIEW_ARTIFACTS_AND_DOCUMENTARY_BINDINGS', 'manifestSha256': manifest_sha,
            'cryptoTokenBindings': count, 'frozenSitesAccountedFor': len(dispositions),
            'frozenReferenceModified': False, 'semanticAdjudicationAutomated': False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--received-zip', required=True, type=Path)
    parser.add_argument('--reference-zip', required=True, type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.root, args.manifest_sha256, args.received_zip, args.reference_zip), sort_keys=True))


if __name__ == '__main__':
    main()
