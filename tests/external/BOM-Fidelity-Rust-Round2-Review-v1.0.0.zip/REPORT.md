# Review of the second Rust CBOM exchange

José Ángel Olivares · BOM Fidelity / Global Trade Origin · 23 October 2026

Review v1.0.0 for Alessandro. Author clarification remains pending.

## Summary

Both received CBOMs validate against the pinned CycloneDX 1.7 schema. Their
143 cryptographic occurrence records anchor to the quoted tokens in the pinned
sources. The 12 JWT choices appear at both the signing call and the normal
signature-verifying call. The HKDF case reports generic HMAC without inventing
a concrete hash.

Alessandro's explanation about HKDF is consistent with a callee-boundary
inventory: the crate implements HKDF itself, while the reported calls are into
HMAC. We accept this as a scope difference from a source reference that also
describes the crate's own extract/expand implementation, not as a missing
HKDF detection.

Three observations merit author review: possible verification annotations on
signature-disabled decode paths; PSS salt/MGF parameters not explicitly
represented; and the absent explicit Ed25519-to-SHA-512 component relation.
These are separate context, parameter and relationship observations, not one
global accuracy score. A public-root scope clarification is listed separately.

## Inputs and integrity

The received `round2-cboms.zip` is 8,810 bytes, SHA-256
`4c941d640521d01baed7f2f2ff3f41e9da1c492d0e9633e05396ca4f1ea5fb09`.

| Received file | SHA-256 |
| --- | --- |
| jwt-cli-6.1.1.cbom.json | `9f10e67bd8383663ffd8f1a2638e7873a7919504acb81ce59662e7cfc1f3b283` |
| hkdf-0.12.4.cbom.json | `183247fea2a8909df2e70f00b95d662e14e2e9a8586ec6c380c79d5bfee7e71e` |

The comparison uses the unchanged **BOM Fidelity Rust Reference Round2
v1.0.0** package:

- Reference ZIP: `d3acc8bcf5ef060ed67c65c30aea98d64fd8258447616b4b3b313bbc8599c47c`.
- Reference MANIFEST.json: `44cc35d53303c0c50a583339bc1597ec2d3e3e256528e7c926770a6cb2531a0d`.
- Reference labels: `b088bb7a78b6f689758b63d08724f24118c4ff07d395b0d6b905a2ceb07b79f4`.

The frozen package, source archives, labels and policy were verified before
each comparison. No label or source interpretation was revised after seeing
the CBOMs. Recorded freeze metadata is not an independent timestamp service.

Alessandro reports using the supplied archives and locks with
nightly-2026-09-25, release and default features, and the HKDF public API without
a harness. The received metadata identifies that toolchain, target
x86_64-unknown-linux-gnu, release profile and the expected binary/library.
This review processes the output documents; it does not rerun his generator
or independently attest his build process.

## Comparable results

| Measurement | jwt-cli 6.1.1 | hkdf 0.12.4 |
| --- | ---: | ---: |
| Total components | 27 | 6 |
| Algorithm components | 15 | 1 |
| Cryptographic occurrence records | 134 | 9 |
| Manifest occurrence records, excluded from operation comparisons | 6 | 6 |
| Cryptographic records with matching source token and quoted line | 134 | 9 |
| Dangling component/dependency references | 0 | 0 |
| Pinned 1.7 schema validation | Valid | Valid |

The 15 JWT algorithm components comprise 12 JWT alternatives plus three SHA-2
component hashes. All 12 alternatives are represented at
`src/translators/encode.rs:126:8` and the normal verification call at
`src/translators/decode.rs:166:36`, where positions are line and zero-based
Unicode offset. They are statically possible selections, not proof that all
12 execute in one invocation.

All 18 application key-preparation sites in the frozen reference have matching
records, including the empty-key preparation and JWK import. These are not
counted as key generation. ECDSA curves agree with the reference. The fixed
signature form is visible in the `*_FIXED`/`*_FIXED_SIGNING` symbols in the
evidence, so we do **not** describe ECDSA encoding as wholly absent merely
because it lacks a separate parameter property.

All nine HKDF HMAC call records match the corresponding source operations or
preparation sites: four tag-operation records and five setup/state-preparation
records. HMAC's hash remains open, as required for the generic case. The
`SimpleHmac` state clone at `src/sealed.rs:83` is not treated as a missing
cryptographic operation. Receiver-start and method-token anchors are normalized
explicitly; for example, reference offsets 39 and prototype offsets 44 at
lines 64 and 95 identify the same finalize call, not different source locations.

`site-alignment.json` gives an explicit disposition for all 85 frozen sites.
Backend internals are linked to originating operations rather than counted as
independent omissions. Public declarations, source sites, component assets and
occurrence records remain distinct units.

## R2-C01 Signature-disabled decode contexts

Classification: **supported source-context difference; interpretation of
conservative annotations requires author clarification**.

Six HMAC occurrence records are labelled `use: verify` at two application
positions: `src/translators/decode.rs:152:21` and `:169:20`, each for
HMAC-SHA-256, HMAC-SHA-384 and HMAC-SHA-512. Their text also says the algorithms
are *possible* through a type join. We retain that qualification rather than
presenting these as definite runtime claims.

The pinned source clones the validator at line 145, disables signature
validation at line 148, and passes this same `insecure_validator` to both calls.
In jsonwebtoken, `src/validation.rs:135` sets `validate_signature` false;
`src/decoding.rs:232` guards the crypto verification call with that flag.
The frozen sites are `J-DISPLAY-DECODE`, `J-NO-SECRET-DECODE` and
`J-DISABLE-SIGNATURE`, with the relevant validation facts retained in v1.

Thus these two contexts decode without verifying a signature. The normal
verification site at line 166 remains a valid positive control and is not
challenged. Could the six annotations preserve the disabled-validation
condition or be distinguished as decoding-only? If they intentionally represent
callee-level over-approximation, that boundary should be stated clearly.
We do not turn this into a blanket false-positive rate or claim to have
observed an incorrect execution.

## R2-P01 Explicit PSS parameters

Classification: **supported representation gap relative to fixed source
parameters, not an incorrect PSS algorithm name or schema violation**.

| Component | Fixed salt bytes | Mask generation | Mask hash |
| --- | ---: | --- | --- |
| RSA-PSS-SHA-256 | 32 | MGF1 | SHA-256 |
| RSA-PSS-SHA-384 | 48 | MGF1 | SHA-384 |
| RSA-PSS-SHA-512 | 64 | MGF1 | SHA-512 |

Ring's `src/rsa/padding/pss.rs:214–217` sets the salt length to the digest output
length; line 89 invokes MGF1 with the selected digest. Frozen facts include
`RG-F-PSS-SALT-LENGTH`, `RG-F-PSS-HASH-LENGTH`, `RG-F-PSS-VERIFY-MGF1`
and the selected SHA-length/configuration facts.

The received PSS components identify the family, hash variant and operations,
but neither their fields, properties nor occurrence text explicitly records
salt length or MGF1. This observation does not require one preferred extension
name: any unambiguous representation with units would work. Would recording
these fixed parameters fit the intended knowledge-base coverage?

## R2-R01 Ed25519 and its component hash

Classification: **supported absence of an explicit component relation;
whether to add it is an author scope decision**.

Both `crypto:algorithm:Ed25519` and `crypto:algorithm:SHA-512` exist, but the
dependency records do not connect them. HMAC, RSA and ECDSA composites do link
to their SHA components. The frozen Ed25519 paths retain the imported-seed,
nonce and challenge hashing sites; the shared challenge helper explicitly
uses SHA-512 in `ring/src/ec/curve25519/ed25519.rs:31`.

We are **not** reporting a missing SHA-512 component or a wrong Ed25519 identity;
the algorithm name already carries meaning. The narrower question is whether
the explicit composite relation should be represented consistently here too.

## Public API scope clarification

The frozen inventory distinguishes HKDF's own API, its inherited methods and
transitive public re-exports. The latter include generic traits and utilities;
their 1,509 declaration/implementation entries are not 1,509 expected crypto
assets or omissions. An unresolved caller-chosen algorithm does not become an
invented SHA or HMAC operation.

Could you confirm whether public re-exports through `hmac`/`digest` were included
as roots, or whether this run covers HKDF's own public implementation boundary?
The metadata's reachable-instance count alone does not answer that question.
No missing-operation count is assigned to those entries while that alignment
is unresolved.

## Repetition and verification

Two isolated VPS runs produced byte-identical intake receipts, comparison
results, source excerpts and review-control results. Each passed 14 review
consistency/documentary-mutation controls. They detect shifted token anchors,
an invented concrete generic hash, dangling relations, and changes to the
specific context/relation observations. They also prevent falsely declaring
the ECDSA fixed form absent from its evidence.

These controls check this review's consistency, not the generator's overall
precision. The prototype was not rerun, no new variant CBOMs are requested,
and the frozen reference remains v1.0.0. JSON was processed as data in
rootless, network-disabled, resource-limited containers with read-only inputs;
no supplied commands or programs were executed.

The accompanying tables preserve the observations and source anchors for
author discussion. Original received CBOMs are identified by hash and are not
bundled for public redistribution. This review and the reference are separate
from the core-java/Dependency-Track collaboration with Dimitri.

[BOM Fidelity](https://bomfidelity.globaltradeorigin.com/)
