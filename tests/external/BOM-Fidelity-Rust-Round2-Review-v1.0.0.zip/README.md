# Second Rust exchange review package

BOM Fidelity · Review v1.0.0 · 23 October 2026

Start with `REPORT.md`. The observations await Alessandro's interpretation;
they are not a global accuracy score or a final agreement between the parties.

The package contains the report, input/freeze identities, occurrence anchors,
all 85 source-site dispositions, focused observations, source evidence and
repeat receipts. It does not contain BOM Fidelity's private comparison engine,
portal, credentials or the original received CBOMs for redistribution.
The two original archives are already held by the exchange participants.

To verify this review on an isolated Linux analysis machine, use Python 3.12
or later with its standard library only:

```sh
python3 verify_review.py . \
  --manifest-sha256 THE_HASH_FROM_THE_SEPARATE_DELIVERY_RECEIPT \
  --received-zip /path/to/round2-cboms.zip \
  --reference-zip /path/to/BOM-Fidelity-Rust-Reference-Round2-v1.0.0.zip
```

The verifier reads archives as data without extracting or executing their
contents. It checks the package manifest, the exact input hashes, the frozen
labels, occurrence/source-token bindings and the documentary observations.
It does not run Rust or the prototype, measure global precision, or replace
semantic source review. Checksums establish integrity against the supplied
identities; they are not digital signatures or independent timestamps.

The review's two comparison runs agreed byte-for-byte and each passed 14
consistency/documentary-mutation controls. The portable package is checked
separately using only this package and the two declared input ZIPs, without
the private study workspace or network access. Runtime files stay outside
the extracted package so its manifest remains unchanged.

Positions use a one-based line and zero-based Unicode character offset.
Caller-selected parameters remain open. Generic public API declarations,
source sites and occurrence records have different denominators. For HKDF,
the author-declared callee boundary is not treated as a missed self-HKDF asset.

Source excerpts come from the previously frozen archives. Their package license
files are supplied under `licenses/`; the original archives retain full
attribution. No upstream endorsement or certification is implied.

No message or public repository was changed automatically. This exchange is
separate from the Java/Dependency-Track check with Dimitri.
