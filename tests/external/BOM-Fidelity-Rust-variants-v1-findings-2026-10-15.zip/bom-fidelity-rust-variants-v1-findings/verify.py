"""Verify the exported findings inventory without running the generator."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / "manifest.json").read_bytes())
expected = set(manifest["files"]) | {"manifest.json"}
actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
if actual != expected or any(p.is_symlink() for p in root.rglob("*")):
    raise SystemExit("FAIL: unexpected or missing package entry")
for name, digest in manifest["files"].items():
    path = (root / name).resolve()
    if not path.is_relative_to(root):
        raise SystemExit("FAIL: unsafe package path")
    if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        raise SystemExit("FAIL: digest mismatch: " + name)
print("PASS: findings package integrity; generator not executed")
