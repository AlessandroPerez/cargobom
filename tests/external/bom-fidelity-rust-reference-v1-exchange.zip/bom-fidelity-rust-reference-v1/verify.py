"""Verify the extracted exchange package without third-party dependencies."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
for name, expected in manifest["files"].items():
    path = (root / name).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise SystemExit("Missing or unsafe package entry: " + name)
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise SystemExit("Hash mismatch: " + name)
labels = json.loads((root / "labels.json").read_text(encoding="utf-8"))
policy = json.loads((root / "evaluation-policy.json").read_text(encoding="utf-8"))
bom = json.loads((root / "reference.cdx.json").read_text(encoding="utf-8"))
assert labels["boundaryReviewSha256"] == manifest["files"]["boundaries.json"]
assert labels["coverageReviewSha256"] == manifest["files"]["coverage.json"]
assert policy["referenceLabelsSha256"] == manifest["files"]["labels.json"]
props = {p["name"]: p["value"] for p in bom["metadata"]["properties"]}
assert json.loads(props["bomfidelity:e05:labelsSha256"]) == manifest["files"]["labels.json"]
assert labels["sourceSha256"] == manifest["files"]["case/src/main.rs"]
assert labels["lockSha256"] == manifest["files"]["case/Cargo.lock"]
assert len(labels["applicationCallSites"]) == 11
assert len(labels["dependencyOperationSites"]) == 41
assert len(labels["dependencyInitializationSites"]) == 6
assert len(labels["configuredCandidates"]) == 32
print("PASS: file hashes, source/lock, reference links and original-case counts")
