# BOM Fidelity Rust reference v1

Technical exchange of the source reference frozen on 14 October 2026, before
inspection of the prototype output. This package covers the original
cbom-real-crates-app case, not the subsequent comparison results.

## Contents

- `reference.cdx.json`: CycloneDX 1.7 reference with explicit source occurrences.
- `labels.json`: 11 application calls, 41 dependency sites with 43 algorithm
  contexts, 6 internal initialization sites and 32 configured candidates.
- `evaluation-policy.json`: fixed matching rules, dimensions and denominators.
- `coverage.json` and `boundaries.json`: origin links, conditions and boundaries.
- `source-audit.json`: pinned crate and selected source hashes.
- `case/`: original source, Cargo manifest, lock and upstream MIT notice.
- `schema-validation.json`: validation against the pinned official schemas.
- `manifest.json` and `verify.py`: exported file hashes and verification.

## Source and locations

Repository: https://github.com/cdxgen/cdxgen-plugins-bin

Commit: `6a646353e4fbd9d64fa115176241d7a233e19630`

Fixture: `thirdparty/rusi/fixtures/cbom-real-crates-app`

Source paths are relative to the fixture or the pinned crate directory.
Application lines and columns start at one; columns count Unicode characters.
Locations are matched before algorithm accuracy is assessed. Raw algorithm
names remain available; different names are not silently treated as equivalent.

The reference separates application operations, initialization/preparation,
dependency operations and configured-only candidates. These are static source
expectations, not observations of runtime execution. Internal iterations and
transparent adapters do not create additional algorithm sites.

## Build context

Toolchain: nightly-2026-09-25, rustc 1.100.0-nightly (f7575a9da 2026-09-24).
Target: x86_64-unknown-linux-gnu. Release profile, default features, pinned lock.
The agreed analysis uses cargo check with -Zalways-encode-mir,
-Zmir-opt-level=0 and -Zspan-free-formats. It does not run the application.
Dependency source files can be retrieved from the crate versions/checksums
in Cargo.lock; their source hashes are recorded in source-audit.json.

## Export and verification

This is a technical export, not a byte-identical copy of the internal snapshot.
Technical expectations and evaluation rules are unchanged. Administrative
review metadata is omitted; links between exported files use their new hashes.
The manifest records original frozen hashes and the explicit export operations.
No prototype output or comparison-based correction is included.

After extracting, run `python verify.py` with Python 3.10 or later. This checks
file integrity and internal hash links; it is not a schema or semantic validator.
The schema validation receipt identifies the schemas used for that separate check.

The five controlled variants and final discrepancy report are separate from
this original-case exchange.

The upstream fixture retains the MIT notice in case/UPSTREAM-LICENSE.
The reference material is supplied for this collaboration; no additional
redistribution licence is assigned by this package.
