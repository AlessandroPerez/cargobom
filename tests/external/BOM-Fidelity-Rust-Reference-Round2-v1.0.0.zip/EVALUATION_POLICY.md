# Evaluation policy for the Rust reference comparison

Version 1.0.0 · BOM Fidelity / Global Trade Origin · 23 October 2026

This policy accompanies the blind source reference for jwt-cli 6.1.1 and hkdf
0.12.4. It fixes how the next comparison will interpret the reference; it is not
a finding about prototype outputs that have not yet been received.

## Match identities and locations

Match the pinned package version and source file first, then the one-based line,
zero-based Unicode character offset and algorithm or operation. A one-based
column is offset plus one. Source hashes distinguish different revisions.
Any documented difference in location convention is normalized explicitly;
it is not silently treated as an algorithm error.

Stable reference IDs and originIds retain application roots and shared
dependency origins. Public declaration spans, macro expansions and application
call sites are distinct units. A dependency operation folded into its originating
application operation is not counted as an omission merely because the
prototype uses a coarser representation. Missing parameters or relationships
are assessed separately from such granularity differences.

## Preserve meaning and unresolved inputs

Compare algorithms using their pinned registry family, variant and explicit
parameters rather than display names alone. Keep byte and bit units distinct;
for example, PSS saltBytes is not an unspecified integer suffix. Fixed values,
caller-dependent values and unresolved values remain separate.

For the generic library, assess only what the library fixes. HMAC or HKDF with
an open hash does not imply SHA-256. A callback or whole algorithm selected by
the caller is unresolved, not absent. The public-boundary dispositions of
generic-array and typenum are not thousands of expected cryptographic assets.

Keep operation, configuration, initialization, key import, unused provider
arguments and conditional execution distinct. Static reachability is not proof
that an operation executes in a real run. Conservative call-graph differences
are classified with their supporting evidence, not automatically as false
positives. Native and indirect-call boundaries retain their documented limits.

## Record findings and denominators

Record each comparison as agreement, justified granularity or scope difference,
supported discrepancy, or unresolved. For a discrepancy, retain both source
evidence and the matching prototype record, including the affected field and
the author's explanation when available.

Report algorithm, operation, parameter, location, relationship and scope results
separately. Counts or rates identify the comparable subset, denominator and
unresolved exclusions. The totals of public API declarations, classified sites
and source facts are different units and must not be mixed into a score. No
global accuracy percentage is inferred from schema validation or these counts.

## Preserve the blind reference

The versioned package and its hashes are fixed before the new prototype CBOMs
are inspected. José Ángel sends the freeze notification and hash before the
exchange. Any correction after the exchange becomes a separate revision with
its reason and effect; the original bytes and initial comparison remain.

The four source-control variants document checks of this reference preparation.
They do not expand the agreed two-case exchange into a request for four more
prototype outputs. Any additional variant exchange is coordinated separately.
