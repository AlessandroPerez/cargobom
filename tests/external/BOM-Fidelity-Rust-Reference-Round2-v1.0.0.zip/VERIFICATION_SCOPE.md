# Scope of the Rust reference verification

The binary's entry point is main. The library's exported functions, methods and
public statics are roots with arguments admitted by their contracts; no harness
fixes a concrete hash. Tests, examples and benches are excluded. Reachability
expectations are static and conditional, not observations of activity.

HMAC and HKDF fix a primitive or family while allowing the caller to choose a
hash. The reference preserves caller-selected hash identities and
HashLen-dependent lengths instead of substituting SHA-256 or a zero length.
General caller-supplied callbacks remain in the companion public-entry table;
they do not become fabricated cryptographic assets.

The CycloneDX files represent the classified source expectations, not a complete
runtime inventory. Occurrences retain source identifiers, origins, conditions
and classifications in additionalContext. Negative contexts and typed API
dispositions remain in reference-labels.v1.json even when they should not create
a cryptographic component occurrence.

Locations use a one-based line and a zero-based Unicode character offset within
that line. Companion columns are one-based. Compiler declaration spans identify
public declarations or implementations, not application operation call sites.
Macro-generated implementations may share a source position; their stable typed
entry identities distinguish them. The 1,310 generic-array and typenum entries
are classifications of typed public boundaries, not audits of their internals.

The schemas are pinned to CycloneDX specification commit
4b3f59453366e27c8073fd24e98bf21ef8892c8e. The cryptography registry is a separate
snapshot acquired on 23 October 2026 with lastUpdated 2026-02-24. Hashes and
acquisition URLs are in standards/acquisition.json. References:

- https://github.com/CycloneDX/specification/tree/4b3f59453366e27c8073fd24e98bf21ef8892c8e/schema
- https://cyclonedx.org/registry/cryptography/
- https://cyclonedx.org/schema/cryptography-defs.json

RSA-PSS salt lengths explicitly use bytes. Unsupported padding enum values are
not introduced to force a family name into a schema field. Curve identifiers
follow the pinned registry. OS randomness is an unresolved system implementation,
not an application-selected named DRBG. Native boundaries are traced without
asserting a review of assembly or which CPU-specific implementation executes.

Schema validity, source hashes and equality with a saved projection establish
integrity and representation consistency. They do not independently establish
the correctness or completeness of the source interpretation, measure the
prototype's precision or demonstrate system security.

Version 1.0.0 freezes the reference before receipt of the two new prototype
CBOMs. The freeze notification is prepared for José Ángel to send; sending it is
separate from preparing this package. Later corrections require a new revision,
preserving the initial reference and explaining the change.
