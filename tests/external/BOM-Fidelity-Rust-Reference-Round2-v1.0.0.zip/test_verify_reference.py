"""Adversarial checks for the portable packet verifier; run in the VPS only."""

import io
from pathlib import Path
import shutil
import tarfile
import tempfile
import unittest

import verify_reference as verifier


ROOT = Path(__file__).resolve().parent


class PacketTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='reference-packet-', dir='/work')
        self.root = Path(self.temporary.name) / 'packet'
        shutil.copytree(ROOT, self.root)
        self.expected = verifier.sha((self.root / 'MANIFEST.json').read_bytes())
        self.manifest = verifier.read_json(self.root / 'MANIFEST.json')
        self.names = verifier.artifact_names(self.manifest)

    def tearDown(self):
        self.temporary.cleanup()

    def reseal(self):
        manifest = verifier.read_json(self.root / 'MANIFEST.json')
        for name in manifest['files']:
            raw = (self.root / name).read_bytes()
            manifest['files'][name] = {'bytes': len(raw), 'sha256': verifier.sha(raw)}
        (self.root / 'MANIFEST.json').write_bytes(verifier.encoded(manifest))
        self.expected = verifier.sha((self.root / 'MANIFEST.json').read_bytes())

    def change(self, name, mutate):
        path = self.root / name
        data = verifier.read_json(path)
        mutate(data)
        path.write_bytes(verifier.encoded(data))
        self.reseal()

    def rejected(self):
        with self.assertRaises((AssertionError, KeyError)):
            verifier.verify(self.root, self.expected)

    def test_valid_packet(self):
        result = verifier.verify(self.root, self.expected)
        self.assertEqual(result['sourceLocationsVerified'], 1720)
        self.assertEqual(result['sourceArchivesVerified'], 11)

    def test_wrong_manifest_anchor(self):
        with self.assertRaises(AssertionError):
            verifier.verify(self.root, '0' * 64)

    def test_changed_bytes(self):
        with (self.root / self.names['labels']).open('ab') as output:
            output.write(b' ')
        self.rejected()

    def test_unlisted_file(self):
        (self.root / 'unexpected.txt').write_text('unexpected')
        self.rejected()

    def test_missing_file(self):
        (self.root / 'configuration.json').unlink()
        self.rejected()

    def test_source_hash_changed_even_when_manifest_resealed(self):
        self.change(self.names['labels'], lambda data: data['facts'][0]['location'].update(sourceSha256='0' * 64))
        self.rejected()

    def test_schema_valid_wrong_algorithm_rejected(self):
        self.change(self.names['jwt-cli'], lambda data: data['components'][0].update(name='Wrong algorithm'))
        self.rejected()

    def test_schema_valid_location_shift_rejected(self):
        def mutate(data):
            row = next(row for row in data['components'] if row.get('evidence'))
            row['evidence']['occurrences'][0]['offset'] += 1
        self.change(self.names['jwt-cli'], mutate)
        self.rejected()

    def test_dangling_origin_rejected(self):
        self.change(self.names['labels'], lambda data: data['sites'][0].update(originIds=['MISSING']))
        self.rejected()

    def test_lock_mismatch_rejected(self):
        path = self.root / 'locks/hkdf.Cargo.lock'
        text = path.read_text()
        import re
        text, count = re.subn(r'checksum = "[0-9a-f]{64}"', 'checksum = "' + '0' * 64 + '"', text)
        self.assertGreater(count, 0)
        path.write_text(text)
        self.reseal()
        self.rejected()

    def test_unsafe_relative_paths(self):
        for value in ['../escape', '/absolute', 'C:/private', 'x\\y', './x', '']:
            with self.subTest(value=value), self.assertRaises(AssertionError):
                verifier.safe_relative(value)

    def test_symbolic_link_archive_rejected(self):
        path = Path(self.temporary.name) / 'bad.crate'
        with tarfile.open(path, 'w:gz') as archive:
            member = tarfile.TarInfo('example-1.0/src/lib.rs')
            member.type = tarfile.SYMTYPE
            member.linkname = '/etc/passwd'
            archive.addfile(member)
        with self.assertRaises(AssertionError):
            verifier.source_members(path, 'example', '1.0')

    def test_traversal_archive_rejected(self):
        path = Path(self.temporary.name) / 'bad.crate'
        with tarfile.open(path, 'w:gz') as archive:
            member = tarfile.TarInfo('example-1.0/../../escape')
            member.size = 1
            archive.addfile(member, io.BytesIO(b'x'))
        with self.assertRaises(AssertionError):
            verifier.source_members(path, 'example', '1.0')

    def test_network_reference_retrieval_denied(self):
        from referencing.exceptions import NoSuchResource
        with self.assertRaises(NoSuchResource):
            verifier.deny_retrieval('https://example.invalid/unlisted-schema')

    @unittest.skipUnless((ROOT / 'FREEZE.json').exists(), 'frozen release only')
    def test_freeze_hash_mismatch_rejected(self):
        self.change('FREEZE.json', lambda data: data.update(labelsSha256='0' * 64))
        self.rejected()

    @unittest.skipUnless((ROOT / 'FREEZE.json').exists(), 'frozen release only')
    def test_freeze_claims_prototype_was_seen_rejected(self):
        self.change('FREEZE.json', lambda data: data.update(prototypeOutputsInspected=True))
        self.rejected()

    @unittest.skipUnless((ROOT / 'FREEZE.json').exists(), 'frozen release only')
    def test_changed_policy_rejected(self):
        path = self.root / 'EVALUATION_POLICY.md'
        path.write_text(path.read_text() + '\nUnrecorded change.\n')
        self.reseal()
        self.rejected()

    @unittest.skipUnless((ROOT / 'FREEZE.json').exists(), 'frozen release only')
    def test_version_mismatch_rejected(self):
        self.change('FREEZE.json', lambda data: data.update(referenceVersion='2.0.0'))
        self.rejected()


if __name__ == '__main__':
    unittest.main(verbosity=2)
