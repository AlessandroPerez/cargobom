# Rust cryptography reference round two

BOM Fidelity / Global Trade Origin · Version 1.0.0 · 23 October 2026

This package freezes the blind source reference for jwt-cli 6.1.1 and hkdf
0.12.4 before receiving the prototype CBOMs for these cases. It includes source
labels, generic public API dispositions, CycloneDX 1.7 reference representations,
pinned source archives and locks, control results, an evaluation policy and a
read-only verifier. It is a reference for the next comparison, not its results.

The reference contains 85 classified source sites, 102 supporting source facts
and 1,533 public declarations or implementations. These are not counts of
algorithms or observed runtime operations. The 1,310 generic-array and typenum
entries describe typed public boundaries, not a line-by-line audit of internals.

## Cases and build configuration

- jwt-cli 6.1.1: repository commit 47d0897ae6465d175fbe10eb554a85466e884c1a,
  published Cargo.lock, binary jwt with main as its root.
- hkdf 0.12.4: RustCrypto/KDFs commit 1ac16e8b9d4ee7a67613c9396c6cc1327652eaba,
  hkdf directory, study Cargo.lock, public API as roots, without a harness.

Both cases use rustc 1.100.0-nightly (f7575a9da 2026-09-24), toolchain
nightly-2026-09-25, x86_64-unknown-linux-gnu, release and default features.
configuration.json records resolved normal/build features and MIR flags. Tests,
examples and benches are outside the study. The original source inventories and
locks were preserved during the controlled checks.

## Verify this package

Use Python 3.11 or later with jsonschema 4.26.0 and referencing 0.37.0. Obtain
dependencies before entering a disposable environment with networking disabled.
The verifier needs neither a Rust toolchain nor the private BOM Fidelity engine.

Obtain the MANIFEST.json SHA-256 from the accompanying message or another trusted
record. From this directory run:

```sh
python -B verify_reference.py . --manifest-sha256 EXPECTED_MANIFEST_SHA256
```

Do not use Python optimization mode. The verifier checks the file manifest,
eleven source archives, 1,720 source locations, frozen metadata, official schemas
with remote retrieval disabled, relationships and the saved representation
profile. It reports JSON and leaves the package unchanged. A hash manifest is an
integrity check, not a signature or proof of semantic correctness.

To run the verifier controls, mount this package read-only and provide a
disposable writable /work directory:

```sh
python -B -m unittest discover -s . -p test_verify_reference.py -v
```

## Read the reference

reference-labels.v1.json is the primary source reference. It retains negative
contexts, generic parameters and conditions that should not become algorithm
occurrences. The two files ending in reference.v1.cdx.json represent the
classified expectations in CycloneDX 1.7. VERIFICATION_SCOPE.md explains the
distinctions; EVALUATION_POLICY.md fixes how the later comparison will treat
locations, origins, generic parameters and scope differences.

FREEZE.json records version metadata, label and policy hashes and continuity
with the verified candidate. MANIFEST.json covers all package files. Any later
correction must create a separate revision, preserving this version's bytes.
The recorded freeze time is not an independent timestamp authority: the
accompanying message establishes the pre-exchange order when it is sent.

The receipt under provenance records the earlier candidate's representation
checks and its earlier filenames and hashes. Likewise, source control receipts
describe the recorded checks before the freeze; their historical candidate
status is not the status of this versioned package.

## Reproduce source builds separately

sources contains eleven unmodified published .crate archives needed to inspect
the labelled locations. source-identities.json gives their URLs and hashes.
Before extraction in a disposable sandbox, check paths, member types and size
limits. Preserve the sources' bundled licences and attribution.

Copy each case's locks file to Cargo.lock in its extracted project. Obtain all
locked dependencies in a separate acquisition step: the eleven included
archives are not a full offline Cargo cache. Then, in an isolated environment
without network, run the first command in jwt-cli and the second in hkdf:

```sh
RUSTFLAGS='-Zalways-encode-mir -Zmir-opt-level=0 -Zspan-free-formats' cargo +nightly-2026-09-25 check --locked --offline --profile release --target x86_64-unknown-linux-gnu --bin jwt
RUSTFLAGS='-Zalways-encode-mir -Zmir-opt-level=0 -Zspan-free-formats' cargo +nightly-2026-09-25 check --locked --offline --profile release --target x86_64-unknown-linux-gnu --lib
```

Compilation can execute third-party build scripts and procedural macros. Use
no shared credentials or production mounts, restricted resources and no network
during compilation. The read-only verifier does not perform these builds.

The four patches under controls each apply to a fresh copy, not cumulatively or
to an original. Their recorded compiler checks confirm a default-algorithm
change, application signing-call removal, output-limit change and preparation
from a supplied PRK. source-controls-acceptance.json retains results and hashes;
verify_reference.py checks that evidence but does not rerun the compiler tests.
These controls are included for reference, not a request for extra prototype
variant runs before the two original cases have been compared.

This package contains no private comparator, portal code, production
configuration, credentials or prototype CBOMs. It is not a security certification.
Third-party sources retain their own licensing terms.

Project: https://bomfidelity.globaltradeorigin.com
