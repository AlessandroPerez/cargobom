"""Portable, read-only checks of reference artifacts, not a crypto detector."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

from jsonschema import Draft7Validator
from referencing import Registry, Resource
from referencing.exceptions import NoSuchResource


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode()


def read_json(path):
    return json.loads(path.read_bytes())


def safe_relative(name):
    path = PurePosixPath(name)
    assert name and not path.is_absolute() and '..' not in path.parts and '\\' not in name
    assert ':' not in name and str(path) == name
    return path


def deny_retrieval(uri):
    raise NoSuchResource(ref=uri)


def package_integrity(root, expected_manifest):
    manifest_path = root / 'MANIFEST.json'
    assert not manifest_path.is_symlink() and sha(manifest_path.read_bytes()) == expected_manifest
    manifest = read_json(manifest_path)
    assert manifest['formatVersion'] == '1.0' and manifest['status'] in ('CANDIDATE_NOT_FROZEN', 'FROZEN_REFERENCE_V1')
    actual = set()
    for path in root.rglob('*'):
        assert not path.is_symlink(), 'symlink in reference packet'
        if path.is_file() and path != manifest_path:
            actual.add(path.relative_to(root).as_posix())
    assert actual == set(manifest['files']), 'missing or unlisted package file'
    for name, expected in manifest['files'].items():
        safe_relative(name)
        path = root / name
        assert path.resolve().is_relative_to(root.resolve())
        assert path.stat().st_size == expected['bytes'] and sha(path.read_bytes()) == expected['sha256'], name
    return manifest


def source_members(path, name, version):
    files = {}
    with tarfile.open(path, 'r:gz') as archive:
        entries = archive.getmembers()
        assert len(entries) < 16384 and sum(row.size for row in entries) <= 128 * 1024**2
        for row in entries:
            parts = PurePosixPath(row.name).parts
            assert parts and parts[0] == name + '-' + version
            assert not row.name.startswith('/') and '..' not in parts and '\\' not in row.name
            assert row.isdir() or row.isfile(), 'non-regular source archive member'
            if row.isfile():
                relative = PurePosixPath(*parts[1:]).as_posix()
                safe_relative(relative)
                assert relative not in files and row.size <= 16 * 1024**2
                handle = archive.extractfile(row)
                assert handle is not None
                with handle:
                    files[relative] = handle.read()
    return files


def validate_sources(root, labels):
    import tomllib
    identity = read_json(root / 'source-identities.json')
    locks = {case: tomllib.loads((root / 'locks' / (case + '.Cargo.lock')).read_text())
             for case in ('jwt-cli', 'hkdf')}
    indexed = {(row['name'], row['version']): row['checksum']
               for lock in locks.values() for row in lock['package'] if 'checksum' in row}
    sources = {}
    for package, value in identity['packages'].items():
        name, version = package.split('@')
        path = root / value['archive']
        assert sha(path.read_bytes()) == value['sha256']
        if name not in ('jwt-cli', 'hkdf'):
            assert indexed[(name, version)] == value['sha256'], 'dependency checksum differs from lock'
        sources[package] = source_members(path, name, version)
    locations = 0
    for key in ('roots', 'sites', 'facts'):
        for row in labels[key]:
            location = row['location']
            raw = sources[location['package']][location['file']]
            assert sha(raw) == location['sourceSha256'], row['id']
            lines = raw.decode('utf-8').splitlines()
            assert 1 <= location['line'] <= len(lines)
            assert location['column'] == location['offset'] + 1
            assert 0 <= location['offset'] < len(lines[location['line'] - 1])
            assert location['path'] == location['package'] + '/' + location['file']
            locations += 1
    return len(sources), locations


def artifact_names(manifest):
    if manifest['status'] == 'FROZEN_REFERENCE_V1':
        return {'labels': 'reference-labels.v1.json', 'profile': 'representation-expectations.v1.json',
                'jwt-cli': 'jwt-cli.reference.v1.cdx.json', 'hkdf': 'hkdf.reference.v1.cdx.json'}
    return {'labels': 'reference-labels.draft.json', 'profile': 'representation-expectations.draft.json',
            'jwt-cli': 'jwt-cli.reference.draft.cdx.json', 'hkdf': 'hkdf.reference.draft.cdx.json'}


def validate_boms(root, labels, names):
    schemas = {}
    registry = Registry(retrieve=deny_retrieval)
    for path in sorted((root / 'standards').glob('*.schema.json')):
        document = read_json(path)
        schemas[path.name] = document
        resource = Resource.from_contents(document)
        for uri in (document.get('$id', document.get('id', 'http://cyclonedx.org/schema/' + path.name)),
                    'http://cyclonedx.org/schema/' + path.name, 'https://cyclonedx.org/schema/' + path.name):
            registry = registry.with_resource(uri, resource)
    Draft7Validator.check_schema(schemas['bom-1.7.schema.json'])
    crypto_registry = read_json(root / 'standards/cryptography-defs.json')
    Draft7Validator(schemas['cryptography-defs.schema.json'], registry=registry).validate(crypto_registry)
    families = {row['family']: row for row in crypto_registry['algorithms']}
    curves = {group['name'] + '/' + row['name'] for group in crypto_registry['ellipticCurves'] for row in group['curves']}
    expectations = read_json(root / names['profile'])
    records = {row['id']: row for key in ('roots', 'sites') for row in labels[key]}
    assert len(records) == len(labels['roots']) + len(labels['sites'])
    for row in labels['sites']:
        assert all(origin in records for origin in row['originIds'])
    counts = {}
    for case in ('jwt-cli', 'hkdf'):
        bom = read_json(root / names[case])
        Draft7Validator(schemas['bom-1.7.schema.json'], registry=registry).validate(bom)
        assert {key: bom[key] for key in ('metadata', 'components', 'dependencies')} == expectations[case]
        properties = {row['name']: row['value'] for row in bom['metadata']['properties']}
        assert properties['bom-fidelity:reference:labelsSha256'] == sha(encoded(labels))
        refs = {bom['metadata']['component']['bom-ref']}
        for component in bom['components']:
            assert component['bom-ref'] not in refs
            refs.add(component['bom-ref'])
            props = component.get('cryptoProperties', {}).get('algorithmProperties', {})
            family = props.get('algorithmFamily')
            if family:
                assert family in families
                assert props['primitive'] in {row['primitive'] for row in families[family]['variant']}
            if 'ellipticCurve' in props:
                assert props['ellipticCurve'] in curves
        component_refs = set(refs)
        occurrences = 0
        for component in bom['components']:
            for occurrence in component.get('evidence', {}).get('occurrences', []):
                occurrences += 1
                assert occurrence['bom-ref'] not in refs
                refs.add(occurrence['bom-ref'])
                context = json.loads(occurrence['additionalContext'])
                source = records[context['recordId']]
                assert source['case'] == case and not context['runtimeObserved']
                assert all(origin in records for origin in context['originIds'])
                location = source['location']
                assert occurrence['location'] == location['path']
                assert occurrence['line'] == location['line'] and occurrence['offset'] == location['offset']
                assert context['sourceSha256'] == location['sourceSha256']
        for edge in bom['dependencies']:
            assert edge['ref'] in component_refs
            assert all(ref in component_refs for ref in edge.get('dependsOn', []) + edge.get('provides', []))
        counts[case] = {'components': len(bom['components']), 'occurrences': occurrences}
    return counts


def verify(root, manifest_sha):
    if not __debug__:
        raise RuntimeError('Run this verifier without -O or PYTHONOPTIMIZE')
    manifest = package_integrity(root, manifest_sha)
    names = artifact_names(manifest)
    labels = read_json(root / names['labels'])
    frozen = manifest['status'] == 'FROZEN_REFERENCE_V1'
    expected_status = 'FROZEN_SOURCE_REFERENCE_V1' if frozen else 'REFERENCE_REPRESENTATION_DRAFT_NOT_FROZEN'
    assert labels['status'] == expected_status
    if frozen:
        record = read_json(root / 'FREEZE.json')
        assert manifest['referenceVersion'] == labels['referenceVersion'] == record['referenceVersion'] == '1.0.0'
        assert record['labelsSha256'] == sha(encoded(labels))
        assert labels['frozenAtUtc'] == record['frozenAtUtc']
        assert record['prototypeOutputsInspected'] is False
        assert record['notificationStatusAtFreeze'] == 'PREPARED_NOT_SENT'
        assert record['evaluationPolicySha256'] == sha((root / 'EVALUATION_POLICY.md').read_bytes())
        assert all(sha((root / name).read_bytes()) == expected for name, expected in record['unchangedCandidateFiles'].items())
    assert not labels['runtimeObserved']
    source_count, locations = validate_sources(root, labels)
    boms = validate_boms(root, labels, names)
    control = read_json(root / 'source-controls-acceptance.json')
    assert control['sourceControlsPassed'] == control['negativeUnchangedControlsRejected'] == 4
    for row in control['controls']:
        assert sha((root / 'controls' / (row['id'].lower() + '.patch')).read_bytes()) == row['patchSha256']
    return {'status': 'PASS_FROZEN_REFERENCE_V1' if frozen else 'PASS_CANDIDATE_NOT_FROZEN', 'manifestSha256': manifest_sha,
            'referenceVersion': manifest.get('referenceVersion'),
            'sourceArchivesVerified': source_count, 'sourceLocationsVerified': locations,
            'roots': len(labels['roots']), 'sites': len(labels['sites']), 'facts': len(labels['facts']),
            'boms': boms, 'privateEngineRequired': False, 'networkReferenceResolutionAllowed': False,
            'checksAreIntegrityAndRepresentationNotIndependentSemanticAccuracy': True,
            'rustProgramsRebuiltOrExecutedByVerifier': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('--manifest-sha256', required=True)
    args = parser.parse_args()
    print(json.dumps(verify(args.root.resolve(strict=True), args.manifest_sha256), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
