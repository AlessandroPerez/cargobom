# Rust CBOM reference cases — round two, v3 review

Review 1.2.0 · 26 October 2026  
José Ángel Olivares · BOM Fidelity / Global Trade Origin  
https://bomfidelity.globaltradeorigin.com/

## Result

The two received v3 documents validate against the pinned official CycloneDX
1.7 schema and registry. The scoped comparison with archived v2 found only the
announced boundary-check summaries and expanded key-provenance annotations.
All 147 cryptographic occurrence records retain their source anchors. Algorithm
identities, parameters, dependency relations and the qualified HMAC candidates
are preserved. No additional algorithm or source discrepancy was found in this
v2-to-v3 comparison.

The frozen source reference, labels, archives and locks were not changed. Review
1.1.0 remains the historical v2 review; this supplement is review 1.2.0. The
published reference release v1.0.0 remains unchanged and citable.

## Inputs and method

| Input | SHA-256 |
| --- | --- |
| `round2-cboms-v2.zip` | `0464092138a292bcecfbeab2ee9bcbb3fd9797c3d77866c6afdb25f20d35f0f8` |
| `round2-cboms-v3.zip` | `8e5a163f93c64d8a49cacbbf40d0c5f89dcba6e3d762f9eae4215429e0db933c` |
| Frozen round-two reference ZIP | `d3acc8bcf5ef060ed67c65c30aea98d64fd8258447616b4b3b313bbc8599c47c` |
| Frozen reference manifest | `44cc35d53303c0c50a583339bc1597ec2d3e3e256528e7c926770a6cb2531a0d` |
| Frozen labels | `b088bb7a78b6f689758b63d08724f24118c4ff07d395b0d6b905a2ceb07b79f4` |

The author identifies generator v3 as
`9a8249cd8afacf8698f6f4cb855cc758a2ec2f78`, and v2 as
`3a8b5efe8659c32c59b68ba1d19762086313e99c`. The declared configuration is the
same reference archives and locks, nightly-2026-09-25, release, default features,
x86_64-unknown-linux-gnu, `-Zalways-encode-mir -Zmir-opt-level=0
-Zspan-free-formats`, with the walk check. These are producer declarations;
this review did not execute the generator or compile either crate.

The review checked bounded ZIP intake, exact input hashes, offline schema
validation, source line/Unicode-offset bindings, component references and the
complete document delta. The existing normalization excludes serial numbers
and compares the declared unordered arrays without discarding duplicates.
Every remaining change is recorded in `differences.json`. A finite expected
edit is compared with the whole document; provenance fields are not masked.

Two isolated passes produced identical review artifacts. Each passed nine
groups of positive checks and 17 documentary mutation controls, including
counter mismatches, a missing or duplicate counter, changed PSS parameters,
a removed dependency edge or occurrence, changed path qualification, invented
provenance, a changed source offset and an invented concrete HKDF hash.
These are review-checker controls, not additional generator executions.

## Observed differences

| Case | Crypto records | Manifest records | Normalized difference records |
| --- | ---: | ---: | ---: |
| jwt-cli 6.1.1 | 138 | 6 | 32 |
| hkdf 0.12.4 | 9 | 6 | 1 |

jwt-cli has one new run property, 16 changed occurrence-context strings and 15
changed aggregate provenance values. hkdf changes only by the new run property
after the stated normalization. Its raw file hash therefore differs from v2;
it is not byte-identical to v2. Neither case gains or loses occurrences.

PSS salt lengths and matching MGF1 hashes, the Ed25519/SHA-512 relation and its
constituent occurrences, all twelve JWT algorithm choices, and generic HKDF
with the caller's hash unresolved remain as reviewed in v2.

## Boundary-check summaries

| Case | Calls | Cited | Unknown | Excused |
| --- | ---: | ---: | ---: | ---: |
| jwt-cli | 247 | 33 | 0 | 214 |
| hkdf | 13 | 9 | 0 | 4 |

Both summaries match the author's message and satisfy both partitions:
`calls = cited + unknown + excused`, and `excused = sum(reason counts)`.

For jwt-cli, the reasons are entered 195, format 11, generator setup 2, view 2,
and one each for accessor, comparison, copy and public half. These sum to 214;
the non-entered reasons sum to 19. For hkdf, copy 2 and internal 2 sum to four.

The supplied property is a textual summary without the individual call list or
resolved-function identities. We verified its representation, announced values
and arithmetic, not an independent enumeration of all 247 or 13 calls. Zero
unknown operations in this summary is not a global completeness or accuracy
claim. Boundary calls and occurrence records also have different units: the
33 cited calls must not be equated with jwt-cli's 138 occurrence records.

## Key provenance and path meaning

The added absent/computed/parameter alternatives occur in jsonwebtoken's
signing, verification and key-setup annotations. Their source origins and
conservative joined interpretation agree with the previously reviewed
application contexts. The full additions, including caller-parameter labels,
are retained in the delta; this review does not reproduce the generator's MIR
call graph or prove feasibility of each alternative at each algorithm branch.

In particular, the empty decoding key and signature-disabled validators remain
at `src/translators/decode.rs:146–152` and `:169`. Those two reference contexts
only decode. Their six HMAC records remain qualified conservative candidates,
not confirmed verifications. Propagating the empty alternative into a shared
sign/verify function is not evidence that an empty key successfully signs or
verifies on an ECDSA or RSA path. Parameter alternatives from different callers
are not a single concrete execution. The computed JWK origin remains parsing
from JWKS, not key generation.

## Library scope and version history

The author's clarification closes the earlier scope note: roots are hkdf's own
public items, not the hmac/digest APIs it re-exports. Calls through those APIs
are attributed to the consuming program's CBOM. All nine HMAC records remain
in hkdf's own source. The earlier note was not scored as a missing-algorithm
finding. No frozen label was revised to accommodate this clarification.

v3 extends the producer's metadata/provenance representation. It does not
replace or invalidate the archived v2 input or the earlier review. The frozen
reference release, producer CBOM revisions and review revisions are separate
version series. This supplement does not modify the public release.

## Package and verification

The accompanying review package includes this report, exact differences,
source excerpts and bindings, hashes, checks and a standard-library verifier.
It excludes the received CBOMs, product source and infrastructure. The verifier
requires the previously exchanged v2 ZIP, v3 ZIP and frozen round-two reference
ZIP. It checks artifact integrity, the exact expected delta and source bindings;
it does not revalidate schemas, compile Rust, run the generator, independently
enumerate boundary calls or automate semantic adjudication. See `README.md`.

The preparation of this package sends no message and changes no public
repository or release. This report is scoped to the two pinned reference cases.
