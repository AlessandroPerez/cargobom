# Rust round-two v3 review 1.2.0

Read REPORT.md for findings and scope. The frozen reference and published
reference v1.0.0 are unchanged; v2 and its review 1.1.0 remain historical inputs.
This supplement compares the two v3 CBOMs with the archived v2 ZIP. It includes
neither received CBOMs nor BOM Fidelity product source or infrastructure.

Use Python 3.11 or newer, without optimization, for a read-only binding check:

```sh
python3 -B verify_v3_review.py . \
  --manifest-sha256 EXPECTED_MANIFEST_SHA256 \
  --v2-zip /inputs/round2-cboms-v2.zip \
  --v3-zip /inputs/round2-cboms-v3.zip \
  --reference-zip /inputs/BOM-Fidelity-Rust-Reference-Round2-v1.0.0.zip
```

Use the manifest SHA-256 from the separate delivery receipt. The three ZIPs
are the original exchanged inputs, not extracted or repacked replacements.
The frozen round-two reference ZIP is distinct from the public release ZIP.
No additional Python dependencies are required. The checker verifies artifact
hashes, the finite expected document edit and all source bindings. It does not
revalidate schemas, run the generator, compile Rust, enumerate the underlying
247/13 boundary calls or automate semantic adjudication. The summaries do not
establish global completeness or feasible execution of joined key alternatives.

Two isolated review passes produced identical outputs; each passed nine groups
of positive checks and 17 documentary mutation controls. These are checks of
the review, not further generator runs. Versioned review data is included.

Prepared for the owner to exchange with the author. This preparation changes
no public repository or release and sends no message automatically.
