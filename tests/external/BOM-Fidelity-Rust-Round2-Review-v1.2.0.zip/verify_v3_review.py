"""Portable integrity, exact-delta and source-binding verifier; stdlib only."""
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
from zipfile import ZipFile
from review_v3_rules import evaluate

if not __debug__:
    raise RuntimeError('Run without Python -O; assertions are required')


def sha(raw): return hashlib.sha256(raw).hexdigest()
def unique(pairs):
    result={}
    for k,v in pairs:
        assert k not in result, 'duplicate JSON key'
        result[k]=v
    return result
def load(raw): return json.loads(raw,object_pairs_hook=unique)
def safe(name):
    p=PurePosixPath(name)
    assert name and not p.is_absolute() and '..' not in p.parts
    assert '\\' not in name and ':' not in name and p.as_posix()==name
def members(path):
    assert path.stat().st_size<16*1024**2
    result={}
    with ZipFile(path) as z:
        entries=z.infolist()
        assert len(entries)<=128 and sum(e.file_size for e in entries)<128*1024**2
        for e in entries:
            safe(e.filename)
            assert not e.is_dir() and not e.flag_bits&1 and e.filename not in result
            assert stat.S_IFMT(e.external_attr>>16) in (0,stat.S_IFREG) and e.file_size<32*1024**2
            result[e.filename]=z.read(e)
    return result


def verify(root,manifest_sha,v2_zip,v3_zip,reference_zip):
    assert not root.is_symlink()
    raw=(root/'MANIFEST.json').read_bytes()
    assert sha(raw)==manifest_sha
    declared=load(raw)['files']
    assert {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}==set(declared)|{'MANIFEST.json'}
    assert not any(p.is_symlink() for p in root.rglob('*'))
    for name,row in declared.items():
        safe(name);data=(root/name).read_bytes()
        assert len(data)==row['bytes'] and sha(data)==row['sha256']
    ids=load((root/'input-identities.json').read_bytes())
    assert sha(v2_zip.read_bytes())==ids['v2ZipSha256']
    assert sha(v3_zip.read_bytes())==ids['v3ZipSha256']
    assert sha(reference_zip.read_bytes())=='d3acc8bcf5ef060ed67c65c30aea98d64fd8258447616b4b3b313bbc8599c47c'
    old,new,frozen=members(v2_zip),members(v3_zip),members(reference_zip)
    assert set(old)==set(new)=={'jwt-cli-6.1.1.cbom.json','hkdf-0.12.4.cbom.json'}
    assert sha(frozen['MANIFEST.json'])==ids['frozenManifestSha256']
    assert sha(frozen['reference-labels.v1.json'])==ids['frozenLabelsSha256']
    ref_manifest=load(frozen['MANIFEST.json'])['files']
    assert set(frozen)==set(ref_manifest)|{'MANIFEST.json'}
    for name,row in ref_manifest.items():
        assert len(frozen[name])==row['bytes'] and sha(frozen[name])==row['sha256']
    for name,row in ids['files'].items():
        assert sha(old[name])==row['v2Sha256'] and sha(new[name])==row['v3Sha256']
        assert (old[name]==new[name])==row['unchangedBytes']
    names={'jwt-cli':'jwt-cli-6.1.1.cbom.json','hkdf':'hkdf-0.12.4.cbom.json'}
    before={c:load(old[n]) for c,n in names.items()};after={c:load(new[n]) for c,n in names.items()}
    delta=evaluate(before,after)
    assert all(delta['checks'].values())
    recorded=load((root/'focused-findings.json').read_bytes())
    assert delta['counters']==recorded['counters'] and all(recorded['checks'].values())
    sources={}
    for pkg,row in load(frozen['source-identities.json'])['packages'].items():
        with tarfile.open(fileobj=io.BytesIO(frozen[row['archive']]),mode='r:gz') as t:
            entries=t.getmembers();prefix=pkg.replace('@','-')+'/'
            assert len(entries)<16384 and sum(e.size for e in entries)<128*1024**2
            sources[pkg]={}
            for e in entries:
                safe(e.name);assert e.isfile() or e.isdir()
                if e.isfile():
                    assert e.name.startswith(prefix) and e.size<16*1024**2
                    name=e.name[len(prefix):];assert name not in sources[pkg]
                    sources[pkg][name]=t.extractfile(e).read()
    expected={(case,c['bom-ref'],i) for case,doc in after.items() for c in doc['components']
        for i,o in enumerate(c.get('evidence',{}).get('occurrences',[]))}
    seen=set();count=0
    for r in load((root/'occurrence-anchors.json').read_bytes()):
        key=(r['case'],r['componentRef'],r['occurrenceIndex']);assert key in expected and key not in seen
        seen.add(key)
        c=next(c for c in after[r['case']]['components'] if c['bom-ref']==r['componentRef'])
        o=c['evidence']['occurrences'][r['occurrenceIndex']]
        assert o['line']==r['line'] and o.get('offset',0)==r['offset']
        assert o.get('additionalContext','')==r['additionalContext']
        if o['location'] in ('Cargo.toml','Cargo.lock') or o['location'].startswith('src/'):
            pkg=r['case']+('@6.1.1' if r['case']=='jwt-cli' else '@0.12.4');file=o['location']
        else:
            prefix,file=o['location'].split('/',1);name,version=prefix.rsplit('-',1);pkg=name+'@'+version
        assert pkg==r['package'] and file==r['file']
        data=frozen['locks/'+r['case']+'.Cargo.lock'] if file=='Cargo.lock' else sources[pkg][file]
        assert sha(data)==r['sourceSha256']
        line=data.decode().splitlines()[r['line']-1];assert line==r['sourceLine']
        assert r['cryptoRecord']==(c['type']=='cryptographic-asset')
        if r['cryptoRecord']:
            match=re.search(r'code: `([^`]+)`',o['additionalContext'])
            assert match and match.group(1)==r['code'] and line[r['offset']:].startswith(r['code'])
            count+=1
    assert seen==expected and count==147 and len(seen)==159
    return dict(status='PASS_ARTIFACTS_EXACT_DELTA_AND_SOURCE_BINDINGS',cryptoTokenBindings=count,
        manifestBindings=12,frozenReferenceModified=False,generatorExecuted=False,
        schemaRevalidatedByPortableVerifier=False,boundaryCallsIndependentlyEnumerated=False)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path)
    p.add_argument('--manifest-sha256',required=True)
    p.add_argument('--v2-zip',type=Path,required=True);p.add_argument('--v3-zip',type=Path,required=True)
    p.add_argument('--reference-zip',type=Path,required=True);a=p.parse_args()
    print(json.dumps(verify(a.root,a.manifest_sha256,a.v2_zip,a.v3_zip,a.reference_zip),sort_keys=True))
