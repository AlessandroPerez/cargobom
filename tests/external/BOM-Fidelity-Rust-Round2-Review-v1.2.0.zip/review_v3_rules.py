"""Public, case-specific documentary delta checks; standard library only."""
import copy
import json
import re

RUN = 'rcbom:run:boundary-check'
EXPECTED = {
    'jwt-cli': (247, 33, 0, 214, {'accessor': 1, 'comparison': 1, 'copy': 1,
        'entered': 195, 'format': 11, 'generator setup': 2, 'public half': 1, 'view': 2}),
    'hkdf': (13, 9, 0, 4, {'copy': 2, 'internal': 2}),
}
SIGN = ('absent (empty) or computed (translators::decode::decoding_key_from_secret) or '
    'computed (translators::encode::encoding_key_from_secret) or '
    'parameter (argument 0 of encode::encode_token::{closure#2}) or '
    'parameter (argument 1 of decoding::decode::) or '
    'parameter (argument 1 of jsonwebtoken::crypto::sign) or '
    'parameter (argument 1 of jsonwebtoken::decoding::decode) or '
    'parameter (argument 1 of jsonwebtoken::decoding::verify_signature) or '
    'parameter (argument 1 of the enclosing function) or '
    'parameter (argument 2 of encoding::encode::) or '
    'parameter (argument 2 of jsonwebtoken::crypto::verify) or '
    'parameter (argument 2 of jsonwebtoken::encoding::encode)')
VERIFY = ('absent (empty) or computed (translators::decode::decoding_key_from_secret) or '
    'parameter (argument 1 of decoding::decode::) or '
    'parameter (argument 1 of jsonwebtoken::decoding::decode) or '
    'parameter (argument 1 of jsonwebtoken::decoding::verify_signature) or '
    'parameter (argument 2 of jsonwebtoken::crypto::verify) or '
    'parameter (argument 3 of the enclosing function)')
SECRET_OLD = ('absent (empty) or computed (translators::decode::decoding_key_from_secret) or '
    'parameter (argument 1 of the enclosing function) or parameter (argument 2 of the enclosing function)')
SECRET_NEW = ('absent (empty) or computed (translators::decode::decoding_key_from_secret) or '
    'parameter (argument 1 of decoding::decode::) or '
    'parameter (argument 1 of jsonwebtoken::decoding::decode) or '
    'parameter (argument 1 of jsonwebtoken::decoding::verify_signature) or '
    'parameter (argument 2 of the enclosing function)')


def canonical(document):
    result = copy.deepcopy(document)
    result.pop('serialNumber', None)
    def visit(value, key=''):
        if isinstance(value, dict):
            return {k: visit(v, k) for k, v in value.items()}
        if isinstance(value, list):
            rows = [visit(v) for v in value]
            if key in ('components', 'dependencies', 'properties', 'dependsOn', 'provides'):
                rows.sort(key=lambda x: json.dumps(x, sort_keys=True))
            return rows
        return value
    return visit(result)


def boundary(document, case):
    rows = [p for p in document['metadata'].get('properties', []) if p['name'] == RUN]
    assert len(rows) == 1, 'one boundary property required'
    raw = rows[0]['value']
    match = re.fullmatch(r'(\d+) calls into crypto packages: (\d+) cited, (\d+) cited by the check as unknown, (\d+) excused \(([^)]+)\)', raw)
    assert match, 'unrecognised boundary summary'
    total, cited, unknown, excused = map(int, match.groups()[:4])
    reasons = {}
    for part in match.group(5).split(', '):
        reason, number = part.rsplit(' ', 1)
        assert reason not in reasons and number.isdecimal()
        reasons[reason] = int(number)
    assert total == cited + unknown + excused, 'total partition'
    assert excused == sum(reasons.values()), 'reason partition'
    assert (total, cited, unknown, excused, reasons) == EXPECTED[case], 'announced counts'
    return dict(total=total, cited=cited, unknown=unknown, excused=excused, reasons=reasons,
        raw=raw, individualCallsProvided=False, independentlyEnumerated=False)


def projected_v3(baseline, case, boundary_property):
    """Apply a finite expected edit, not an unrestricted provenance-field mask."""
    result = copy.deepcopy(baseline)
    assert all(p['name'] != RUN for p in result['metadata']['properties'])
    result['metadata']['properties'].append(copy.deepcopy(boundary_property))
    if case == 'hkdf':
        return result
    components = {c['bom-ref']: c for c in result['components']}
    def context(ref, index, field, before, after):
        row = components[ref]['evidence']['occurrences'][index]
        assert row['location'].startswith('jsonwebtoken-9.2.0/')
        token = '; ' + field + ': ' + before + '; line: '
        assert row['additionalContext'].count(token) == 1
        row['additionalContext'] = row['additionalContext'].replace(token, '; '+field+': '+after+'; line: ')
    def prop(ref, key, old):
        rows = [p for p in components[ref]['properties'] if p['name'] == 'rcbom:provenance:'+key]
        assert len(rows) == 1 and rows[0]['value'] == old
        rows[0]['value'] = 'absent,computed,parameter'
    for bits in (256, 384):
        ref = f'crypto:algorithm:ECDSA-P-{bits}-SHA-{bits}'
        context(ref, 2, 'key', 'parameter (argument 1 of the enclosing function)', SIGN)
        context(ref, 4, 'public-key', 'parameter (argument 3 of the enclosing function)', VERIFY)
        prop(ref, 'key', 'parameter'); prop(ref, 'public-key', 'parameter')
    context('crypto:algorithm:Ed25519', 3, 'public-key', 'parameter (argument 3 of the enclosing function)', VERIFY)
    prop('crypto:algorithm:Ed25519', 'public-key', 'parameter')
    for bits in (256, 384, 512):
        ref = f'crypto:algorithm:HMAC-SHA-{bits}'
        context(ref, 1, 'key', 'parameter (argument 1 of the enclosing function)', SIGN)
        prop(ref, 'key', 'parameter')
        for family in ('RSA-PKCS1-1.5', 'RSA-PSS'):
            ref = f'crypto:algorithm:{family}-SHA-{bits}'
            context(ref, 0, 'public-key', 'parameter (argument 3 of the enclosing function)', VERIFY)
            prop(ref, 'public-key', 'parameter')
    ref = 'crypto:material:private-key:RSA'
    context(ref, 0, 'key', 'parameter (argument 1 of the enclosing function)', SIGN)
    prop(ref, 'key', 'computed,parameter')
    context('crypto:material:secret-key:HMAC', 0, 'key', SECRET_OLD, SECRET_NEW)
    return result


def evaluate(before, after):
    checks, counters = {}, {}
    for case in ('jwt-cli', 'hkdf'):
        try:
            counters[case] = boundary(after[case], case)
            checks[case+'-counter-partitions-and-announced-values'] = True
        except (AssertionError, KeyError, TypeError, ValueError):
            checks[case+'-counter-partitions-and-announced-values'] = False
        try:
            rows = [p for p in after[case]['metadata']['properties'] if p['name'] == RUN]
            assert len(rows) == 1
            expected = projected_v3(before[case], case, rows[0])
            checks[case+'-only-exact-announced-edits'] = canonical(expected) == canonical(after[case])
        except (AssertionError, KeyError, TypeError, ValueError, IndexError):
            checks[case+'-only-exact-announced-edits'] = False
    return dict(checks=checks, counters=counters)
